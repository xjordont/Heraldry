---
name: heraldry-classic-ink-art
description: Runs the Heraldry Skirmish illustration queue from the GitHub repo xjordont/heraldry. For each queued item it generates one black pen-and-ink illustration from the repo's prepared prompt and that item's own short reference set, checks it against the prompt's must-show and do-not-draw lists, saves it unmodified to assets/art/incoming/<ID>.<ext>, logs a receipt and commits in small batches. Use when asked to generate, resume, redo or review Heraldry artwork. Never writes or edits prompts, the manuscript or tools.
---

# Heraldry Skirmish illustration runner (v6)

## Who does what

The repo is the single source of truth. Claude Code, a separate agent, writes every prompt, queue, reference set and review. You generate images and deliver them. `production/art/gpt/QUEUE.json` says what to draw, `production/art/gpt/prompts/<ID>.txt` is the exact prompt for each item, and `production/art/ILLUSTRATION_LIST.md` (the owner's "illustrations.md") is the human-readable catalogue of the same prompts. If the list and a prompt file ever differ, the prompt file wins. Never run from the list.

You do not plan scenes or write prompts. The planning was done and audited for uniqueness before the queue was published. Improvising at run time is where drift, duplicates and contradictions of the rulebook come from.

**Precedence.** An item's own prompt, must list and do-not-draw list override every general note in this skill, including the family notes and the style page. The prompt's own wording wins over this skill's shorthand: its "warm ivory-white paper", for example, is the flat near-white paper the checks mean. If the repo's `production/art/gpt/INSTRUCTIONS.md` or the queue differs from this skill on a repo mechanic (paths, queue fields, receipt fields, commit message), follow the repo and say so in your report. The hard rules below never relax.

## Hard rules

1. Use each prompt file verbatim as the image prompt. Do not shorten, paraphrase, translate or "improve" it. The only permitted addition is up to two correction sentences on a retry (`references/REPAIR.md`), which you record in the receipt notes.
2. Attach only the images in that item's `references` (at most three). Attach nothing else. Never attach the whole reference folder.
3. Generate only IDs listed in `QUEUE.json`. An image is delivered once it is pushed. Never regenerate a delivered image unless `status` lists it as `redo` or the owner asks. A redo starts a fresh attempt budget, and `show` prints the reviewer's reason: base your correction sentence on it. If the reason conflicts with the prompt's must or do-not-draw lines, the prompt wins; say so in your report. Before the push you may regenerate freely, inside the item's attempt budget.
4. The item's `size` is the minimum and fixes the aspect: wide 3:2 (1536x1024), tall 2:3 (1024x1536) or square 1:1 (1024x1024). Request the largest size and highest quality the tool offers at that aspect; a larger native image at the same aspect passes. Use the GPT Image 2.5 Sunburst model if the tool offers it (owner request), otherwise the default image model, and record the exact model name shown with `save --model`. No upscaling and no print preparation: the repo's intake does that.
5. Save the image exactly as the tool delivered it. No crop, resize, sharpen, retouch or format conversion.
6. Change no file in the clone except `assets/art/incoming/<ID>.<ext>` and `production/art/gpt/RECEIPTS.jsonl`. Keep everything else you create (downloaded images, previews, contact sheets, bundles) in the scratch folder, outside the clone. `doctor` prints its location and the helper uses it by default (set `HERALDRY_SCRATCH` to another folder outside the clone if the system temp folder is not available). Do not edit the manuscript, queue, prompts, tools or this skill. No branches. No force-push.
7. Never call the images hand-drawn and never mark one approved. Claude Code reviews and approves.
8. Work without asking for confirmation between items. Stop only at the stop conditions below.

## The helper

The helper lives in the repo, so this path is always right and always matches the queue. Run it from the repo root and write the full command each time:

```
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py <command>
```

| Command | Use |
|---|---|
| `doctor` | environment, repo, queue and reference checks; prints the scratch folder |
| `status [--end]` | queue state and the single next action; `--end` at session end |
| `next [--n N]` | the next items to generate (8 unless `--n`) |
| `show ID` | references, size, size class, MUST BE SHOWN and DO NOT DRAW lists, verbatim prompt |
| `check ID FILE` | tripwires for one generated image; counts it as an attempt; writes a print-size preview |
| `save ID FILE ...` | check again, copy the bytes untouched, write the receipt |
| `refuse ID --reason "..."` | record that the image tool refused an item |
| `sheet [ID ...] [--refs]` | contact sheet of saved images; `--refs` adds their references |
| `bundle [--evidence FILE ...]` | review hand-off zip (native images, receipts, QA reports, hash manifest) when git cannot push |
| `work_preflight.py` | read-only Python, LFS, queue, references, remote auth and model-smoke status; `--offline-package` verifies a Work input package without Git |
| `fidelity_gate.py` | create/verify byte-bound QA JSON (all ten criteria require visual evidence) |
| `delivery_guard.py` | `audit`, `ship --execute`: verify native hashes, receipts, reference and prompt hashes, clean index, and Git LFS before delivery |
| `style_audit.py` | advisory four-edge and same-register style drift report (scratch only); supplements the contact sheet |

## Session start

**Two input routes.** (a) An authenticated Git checkout, below. (b) An **offline Work input package**: a ZIP that Claude Code builds with `tools/art_work_package.py` from a named commit, holding the exact queue, its prompt files, every queue-listed reference as real image bytes, this complete skill, receipts and selection state, each with SHA-256 in `WORK_PACKAGE.json`. Use (b) when shell git cannot authenticate or the GitHub connector cannot fetch the binary references. Unzip it into an empty folder, treat that folder as the clone, and follow its `START_HERE.md`: `work_preflight.py --repo . --offline-package --require-installed` must say READY with `delivery: bundle` and `remote_access: NOT_ATTEMPTED`. Never `git init`, clone or pull there. Everything else in this skill applies unchanged except delivery: `delivery_guard.py` needs Git and refuses, so every batch ends with `bundle` and an explicit statement that nothing was pushed. The package proves only its inputs; the image-reference and native-file smoke test is still yours to do.

Route (a), first time only: clone `xjordont/heraldry` (a private repo; use the access the owner gave you) with `GIT_LFS_SKIP_SMUDGE=1` set, then run `git lfs install --local --skip-smudge` inside it. That keeps the private reference PDFs, and every other large file you do not need, from being downloaded now or by later pulls.

Every session, from the repo root, first run `python production/art/skill/heraldry-classic-ink-art/scripts/work_preflight.py --repo . --require-installed` and follow `references/WORK_OPERATIONS_V6.md`. A GitHub connector without local Git LFS is not a substitute for a successful push. Then:

```
# Only pull while the checkout is clean. If prior images/receipts are unsent,
# use status and the guarded delivery/bundle procedure instead of rebasing.
git pull --ff-only origin main
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py doctor
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py status
```

If `doctor` says NOT READY YET, run the single `git lfs pull --include="..."` command it prints (reference images that are still LFS pointers), then run `doctor` again. `doctor` must say READY, or READY TO GENERATE (see the no-git stop condition). `status` prints the single next action. Obey it.

## Phases

- `anchors` (currently 5 images). Generate them, push, then stop. Tell the owner: "Anchors done. Ask Claude Code to review them and publish the batch queue." Do not start the batch. If an anchor was refused, say so; Claude Code decides what that means for the batch.
- `batch`. Work through the queue in order and keep going between deliveries until `status` says NOTHING LEFT. References are only the owner's hand-inked samples; approved images are never references.

## For each item

1. `show ID`. Read the MUST BE SHOWN and DO NOT DRAW lists before generating.
2. Attach the listed references. Paste the whole prompt. Request the size. If the image tool cannot accept every required reference, STOP and report a capability blocker; do not silently proceed with an unanchored image. If the tool shows you a revised prompt or shortens yours, report the deviation and do not attest that the queued prompt was unchanged.
3. Save the tool's image into the scratch folder, never inside the clone. Run `check ID FILE`. It counts the attempt (every distinct image you check is one; the count carries on through a redo before the push and starts afresh only after the image has been delivered and sent back), prints the tripwires, writes a print-size preview and lists the MUST and DO NOT DRAW lines again. Look at the image and at the preview and check each of the ten hard fails below (each is true or false). Count the must-show items yourself: the tripwires cannot. Keep every attempt's file in the scratch folder until the item is saved, so you can go back to the best one; each attempt's preview is kept too. Some DO NOT DRAW lines name another entry ("Not the Undead Champion"): before you attest, open that entry's reference image if it is among your references, or its delivered image (`assets/art/incoming/<ID>.<ext>`); if neither exists, read what that entry's own prompt describes (`show` its ID) and make sure your attempt is not that.
4. No hard fail: first create and finish a scratch visual QA JSON following `references/STYLE_CONSISTENCY_V6.md` and `references/WORK_OPERATIONS_V6.md`, set `visual_review_at_print_size: true` and `register_compared` accurately, then run `save ID FILE --qa-file /scratch/ID.qa.json --must "<what you counted or found>" --avoid-clear --model "<image model if shown>" --notes "<anything unusual, including any correction sentence you added>"`. Give exactly one `--must` for each MUST line, in order, each a real statement such as `"counted 8 legs, 4 a side"`; give none if the list is empty. `--avoid-clear` states that you looked and none of the DO NOT DRAW items is present. `save` checks again, copies the bytes untouched with the true extension, and appends the receipt with the attempts the helper counted, your statements and the attestation. Add `--redo` only when the owner asked you to replace an image that was already delivered; items that `status` lists as `redo` need no flag. `--attempts N` can only raise the count the helper recorded, for images you generated but did not check.
5. Any hard fail: retry using `references/REPAIR.md`, up to the item's `max_attempts` (usually 3; cover and chapters 5). Stop at the first attempt with no hard fail. After the last allowed attempt, save the best attempt with `save ID FILE --qa-file /scratch/ID.qa.json --accept-flags --notes "<what is still wrong>"`. The best attempt is the one that breaks the fewest hard fails; if tied, the one whose subject is most accurate. It is never a byte copy of another image. The helper refuses `--accept-flags` until you have checked as many images as the budget allows, and it marks the receipt. It is for nothing else. If every attempt was a copy of a reference or of another image, save nothing: `refuse ID --reason "the tool keeps returning a copy of <path>"`. Then move on.

## Hard fails: reject the variant if any is true

1. Wrong subject, or anything contradicts SOURCE TEXT.
2. A "Must be shown exactly" item is missing or miscounted. Count limbs, eyes, heads and weapons.
3. A "Do not draw" item is present.
4. Any lettering, runes, signature, watermark, caption or pseudo-writing.
5. Colour, grey wash, gradients or paper texture. Ink marks only, on flat, even paper (the warm ivory-white the prompt asks for is fine).
6. A frame, box or hard crop. A figure or still life that is not isolated on white with about 8% margin and nothing cropped. A scene that does not fade to white on all four sides.
7. Subject bleed from a reference (oaks, standing stones, a palisade gate, a timber bridge, a skeleton with a shield) that the prompt did not ask for.
8. Broken anatomy or construction: wrong limb counts, unheld weapons, floating parts, impossible architecture, cloned elements.
9. A human scale figure the prompt did not ask for, or a requested one missing. Scale follows the prompt: a creature's `Size:` line, or the people a scene says it has.
10. The subject is not unmistakable in the print-size preview.

A must-show item and a do-not-draw line that look opposed are almost always about scale or focus. A required grove circle beside "do not repeat the grove scenario" means: draw the circle small, in the middle distance as the composition says, and do not make it the subject. Satisfy both the narrowest way and carry on. A prompt that cannot be satisfied at all is not for you to fix or to burn attempts on: `refuse ID --reason "prompt cannot be satisfied: <what clashes>"` and move on (`references/REPAIR.md`).

Details, soft style checks and the batch drift review: `references/QA_CHECKLIST.md`. Style and the registers: `references/STYLE.md`. Family defaults: `references/FAMILIES.md`.

## Batches and pushes

`status` asks for a push when the queue's `push_every` images (default 5; the batch queue sets 10) are saved and unsent, when nothing is left to generate, and at session end if you run `status --end`. Never hold more than twice that unsent.

1. Drift review first: use `sheet --refs` **and** run `style_audit.py --repo . --limit 10 --out /scratch/batch_style.json` outside the clone. Read `references/VISUAL_ACCEPTANCE_V6.md`. The contact sheet puts the saved, unpushed images beside the references of every item on the sheet. Look for drift (thicker or thinner line, grey tone, different finish), repeated poses or compositions, and scenery behind figures. Redo the one or two worst before you push; the attempt budget still counts every attempt.
2. After the drift review, use the v6 allowlist and LFS guard. This keeps the current single-producer `main` intake, but does not silently overwrite concurrent changes:

```
python production/art/skill/heraldry-classic-ink-art/scripts/delivery_guard.py audit --repo .
python production/art/skill/heraldry-classic-ink-art/scripts/delivery_guard.py ship --execute --repo .
```

If the guard blocks (remote advanced, unknown local modification, missing Git LFS, authentication, or rejected LFS staging), do **not** force push, auto-rebase, or assume successful delivery. Use `bundle`, report that no push occurred, and ask the repository maintainer to reconcile the changes. The guard commits only queue IDs under `assets/art/incoming` and the JSONL receipts. The receiver controls review, inking, proofs and approval.

3. At the end of a session run `status --end`, do what it says, then write the report.
4. Style drift is a known risk in very long image threads. After about 20 items, suggest the owner start a fresh conversation and paste the resume prompt from `OPERATOR_CARD.md`.

## Stop conditions

- The anchors are done, or the queue is empty.
- The whole batch has drifted: the drift review shows the same fault in most of the images, not in one or two. Push what is good, stop, and tell the owner.
- The image tool refuses an item. Do not reword the prompt to get around it. Record it with `refuse ID --reason "<the tool's message, or what happened if it gave none>"` (its receipt line goes in with the next batch), list it in your report, and continue with the next item.
- Quota or rate limit, or the tool stops returning images without refusing (two attempts in a row with no image). Push what is saved, report the counts and the next ID, and stop. Nothing is recorded for an item you did not finish.
- `doctor` says NOT READY (not "NOT READY YET", which has its own one-step fix): a broken queue, prompts or references, or a branch other than main. Also a prompt that does not match its queue hash after a pull, or a queue that is schema 1. Report it and stop.
- `doctor` says delivery by git is blocked (no git or git-lfs): keep generating and saving, and finish each batch with `bundle`; hand the zip to the owner. If you cannot run Python either, do the same steps by hand and deliver the images, named `<ID>.<ext>` with their true extension, with one receipt line each (`references/QA_CHECKLIST.md` shows the format).

## Report at the end of every session

IDs saved and pushed, attempts used, items saved with `--accept-flags`, items refused, differences you found between the repo and this skill, the next ID. State plainly what you could not verify.

## Not in the queue

Do not generate it. Ask the owner to have Claude Code add it to the catalogue. For an explicit one-off outside the book, see `references/AD_HOC.md`.


## V6 release gates and precedence clarification

The exact queued prompt and its must/avoid clauses remain authoritative. The present skill adds **release-process** requirements, not new subject facts. These take precedence over v4-era delivery shorthand in the repository until the maintainer has installed the v6 replacement instructions. No visual QA record may override the prompt; if the prompt contradicts canonical lore, refuse and escalate for Claude Code to fix upstream.

- **Mandatory Work capability smoke test:** `references/WORK_OPERATIONS_V6.md`, plus `scripts/work_preflight.py` for environment, reference and Git LFS checks. Work must actually demonstrate image-reference attachment and native file access; the script cannot discover those independently.
- **Mandatory image-bound visual QA:** `scripts/fidelity_gate.py` creates a JSON report outside the clone. Complete all ten visible criteria, list concrete evidence, and save with `--qa-file`. The helper refuses incomplete or stale reports. A clean mechanical `check` does not substitute for human/visual review. See `references/STYLE_CONSISTENCY_V6.md`.
- **Native dimensions (owner 2026-10-11):** the queue size is the minimum at a fixed aspect. Request the largest size the tool offers at that aspect and record what it produced. A smaller or off-aspect image is a **recorded exception requiring reviewer approval**.
- **Git concurrency and LFS:** instead of manually following v4's `git add`/`commit`/`pull --rebase` sequence, use `scripts/delivery_guard.py audit --repo .` then `ship --execute --repo .`. It blocks on remote divergence, changes outside allowed paths and missing LFS, with no force-push. If blocked, use `bundle` and report that Git delivery did not occur. This preserves the current direct-to-main intake contract; switching to PRs requires a separate coordinated repo change.
- **Independent review:** the five anchors are a mandatory stop after delivery. The repository reviewer or owner must approve them and publish a new queue. Work never self-approves based on a numerical score.
- **Deployment:** this ZIP does not mutate GitHub. Before autonomous running, maintainer must install the skill, updated runner and repository standing instructions as set out in `deployment/REPOSITORY_UPGRADE.md`. Use the Work smoke-test phase first.

## V6 additional safety gates

- `delivery_guard.py audit` checks that each changed image matches the **latest** exact SHA-256 native-image receipt; that its reference files remain unchanged since review; that the current prompt matches the queued hash; and that all ten QA criteria contain evidence. The guard rejects a dirty staging index, unexpected paths, missing LFS, or remote divergence. Do not bypass this guard by direct `git add`/`push`.
- Complete the explicit printed-width review and comparison-register fields in the QA record. Compare four-edge ink statistics with an actual visual inspection; a number is never proof of a successful vignette.
- Run a register-specific batch drift report using `scripts/style_audit.py`, saved outside the checkout, alongside each contact sheet. When shared drift is present across two sibling images, stop and hand back the issue for upstream review.
- Start only after `work_preflight.py --require-installed` confirms the live clone contains v6, then perform a **real** image-reference and native-file smoke test. Replacing only this ZIP without deploying the repository files is insufficient.
