# Heraldry ChatGPT Work input package: START HERE

Source: `xjordont/Heraldry` `main` commit `abf1a740a75df9881eeca80e4589465c563be6d8`. Queue phase `batch`, 270 items.
This package replaces the authenticated Git checkout for **inputs only**. It holds the exact queue, prompts,
references (real image bytes), the complete v6 skill, receipts and selection state, with SHA-256 for every file
in `WORK_PACKAGE.json`. It cannot push anything to GitHub, and it approves nothing.

## 1. Unpack and verify (no Git, no credentials)

Unzip into the new empty folder `/mnt/data/heraldry_work` (any empty folder works; these paths assume this one) and
run every command from inside it. Do not run `git init`, `git clone` or `git pull` here. The helper keeps attempt
counts, print-size previews and QA copies in the sibling folder `/mnt/data/heraldry_work_scratch`; put your own scratch files
(native images, QA JSON, smoke record) there too, never inside the package folder.

```
cd /mnt/data/heraldry_work
python production/art/skill/heraldry-classic-ink-art/scripts/work_preflight.py --repo . --offline-package --require-installed
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py doctor
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py status
```

Expected: `status` READY, `source.kind` offline_package, `delivery` bundle, `remote_access` NOT_ATTEMPTED,
`image_and_reference_tool` UNVERIFIED. Any BLOCKED result: stop and report it word for word. Never edit a
packaged file; the preflight rejects any change (receipts may only grow).

## 2. Smoke test inside Work (required; no script can do it)

Confirm that the image tool accepts every reference of an item as an attached image and that the generated
native file is on disk where Python can read it. Only if all three are true, write `/mnt/data/heraldry_work_scratch/smoke.json`:
`{"image_generated": true, "all_queue_references_attached": true, "native_file_accessible": true, "note": "..."}`
and rerun the preflight with `--smoke-file /mnt/data/heraldry_work_scratch/smoke.json`. If the tool cannot take every listed
reference, STOP and report a capability blocker. Never generate without them.

## 3. Generate the queued items (batch phase, 270 items)

1. `ART-BAS-DEEPWARDEN` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
2. `ART-BAS-HEARTHHOLD` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
3. `ART-BAS-REEDMARCH` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
4. `ART-BAS-SABLEKEEP` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
5. `ART-BAS-SALTSPIRE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
6. `ART-CLI-THE-ASHLANDS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
7. `ART-CLI-THE-MIRE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
8. `ART-CLI-THE-PALE-CITY` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
9. `ART-CLI-THE-SUN-DROWNED` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
10. `ART-CLI-THE-UNDERMARCHES` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
11. `ART-MON-ASHEN-REVENANT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
12. `ART-MON-BANDIT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
13. `ART-MON-BANDIT-CAPTAIN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
14. `ART-MON-BANSHEE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
15. `ART-MON-BASILISK` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
16. `ART-MON-BEASTMAN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
17. `ART-MON-BLACK-DRAGON` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
18. `ART-MON-BLACKFIRE-HOUND` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
19. `ART-MON-BLACKWATER-WIGHT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
20. `ART-MON-BLOOD-APE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
21. `ART-MON-BLUE-DRAGON` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
22. `ART-MON-BOGLING` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
23. `ART-MON-BRASS-GOLEM` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
24. `ART-MON-BRIARLING` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
25. `ART-MON-BUGBEAR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
26. `ART-MON-BURROWMAW` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
27. `ART-MON-CAVE-GOBLIN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
28. `ART-MON-CORPSEHOUND` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
29. `ART-MON-CROCODILE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
30. `ART-MON-CRYPTSTRANGLER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
31. `ART-MON-DEEP-ELF-PRIEST` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
32. `ART-MON-DEEP-ELF-WARRIOR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
33. `ART-MON-DEMON` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
34. `ART-MON-DESERT-NAGA` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
35. `ART-MON-DIRE-BEAR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
36. `ART-MON-DIRE-WOLF` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
37. `ART-MON-DRYAD-GROVEWARDEN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
38. `ART-MON-ELDER-VRYMK` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
39. `ART-MON-EMBER-SKULL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
40. `ART-MON-EVIL-EYE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
41. `ART-MON-FALLEN-PALADIN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
42. `ART-MON-FIRE-BEETLE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
43. `ART-MON-FIRE-ELEMENTAL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
44. `ART-MON-FOREST-TROLL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
45. `ART-MON-FORSAKEN-ARCHER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
46. `ART-MON-FORSAKEN-DUELIST` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
47. `ART-MON-FORSAKEN-KNIGHT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
48. `ART-MON-FROST-GHOUL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
49. `ART-MON-FROST-GIANT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
50. `ART-MON-FROST-WYVERN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
51. `ART-MON-FROZEN-SKELETON` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
52. `ART-MON-GARGOYLE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
53. `ART-MON-GELID-FIEND` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
54. `ART-MON-GHOUL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
55. `ART-MON-GIANT-BAT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
56. `ART-MON-GIANT-BLACK-WIDOW` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
57. `ART-MON-GIANT-CENTIPEDE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
58. `ART-MON-GIANT-CONSTRICTOR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
59. `ART-MON-GIANT-SCORPION` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
60. `ART-MON-GIANT-SKELETON` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
61. `ART-MON-GIANT-TARANTULA` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
62. `ART-MON-GLOOM-HULK` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
63. `ART-MON-GLOOMSPORE-JELLY` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
64. `ART-MON-GNOLL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
65. `ART-MON-GOBLIN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
66. `ART-MON-GOBLIN-SHAMAN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
67. `ART-MON-GOREBEAK-BEAR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
68. `ART-MON-GREEN-DRAGON` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
69. `ART-MON-HARPY` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
70. `ART-MON-HYDRA` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
71. `ART-MON-ICE-ELEMENTAL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
72. `ART-MON-ICE-WRAITH` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
73. `ART-MON-IMP` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
74. `ART-MON-IRON-GOLEM` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
75. `ART-MON-KOBOLD` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
76. `ART-MON-LICH` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
77. `ART-MON-LIZARDFOLK-HUNTER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
78. `ART-MON-LIZARDFOLK-SHAMAN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
79. `ART-MON-LIZARDFOLK-WARRIOR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
80. `ART-MON-MANTICORE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
81. `ART-MON-MEDUSA` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
82. `ART-MON-MIASMA-SERPENT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
83. `ART-MON-MINOTAUR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
84. `ART-MON-MIRE-TITAN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
85. `ART-MON-MUMMY` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
86. `ART-MON-NIGHT-HAG` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
87. `ART-MON-NOXCLOTH` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
88. `ART-MON-OGRE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
89. `ART-MON-ORC` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
90. `ART-MON-POSSESSED-CORPSE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
91. `ART-MON-RATKIN-SCAVENGER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
92. `ART-MON-RATKIN-SEER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
93. `ART-MON-RATKIN-WARRIOR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
94. `ART-MON-SATYR-REVELER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
95. `ART-MON-SHAMBLING-MOUND` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
96. `ART-MON-SKELETAL-BEAST` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
97. `ART-MON-SKELETON-ARCHER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
98. `ART-MON-SKELETON-WARRIOR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
99. `ART-MON-SNOW-GOBLIN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
100. `ART-MON-SPECTRE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
101. `ART-MON-STIRGE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
102. `ART-MON-STONE-SENTINEL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
103. `ART-MON-SWAMP-GOBLIN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
104. `ART-MON-SWAMP-HAG` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
105. `ART-MON-SWAMP-NAGA` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
106. `ART-MON-SWAMP-TROLL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
107. `ART-MON-THOUGHT-EATER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
108. `ART-MON-TOMB-GUARDIAN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
109. `ART-MON-TOMB-NECROMANCER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
110. `ART-MON-TROGLODYTE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
111. `ART-MON-TROGLODYTE-SHAMAN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
112. `ART-MON-TUNDRA-WOLF` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
113. `ART-MON-UNDEAD-CROSSBOWMAN` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
114. `ART-MON-UNDEAD-SENTINEL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
115. `ART-MON-UNDEAD-WARRIOR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
116. `ART-MON-VAULT-OOZE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
117. `ART-MON-VAULTFANG` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
118. `ART-MON-VRYMK` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
119. `ART-MON-WEREBEAR` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
120. `ART-MON-WERERAT` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
121. `ART-MON-WEREWOLF` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
122. `ART-MON-WHITE-COURT-ARCHER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
123. `ART-MON-WHITE-COURT-EXECUTIONER` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
124. `ART-MON-WHITE-COURT-GUARD` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
125. `ART-MON-WHITE-COURT-SENTINEL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
126. `ART-MON-WHITE-DRAGON` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
127. `ART-MON-WILL-O-WISP` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
128. `ART-MON-WIND-ELEMENTAL` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
129. `ART-MON-ZOMBIE` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
130. `ART-CLA-ASSASSIN` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
131. `ART-CLA-BERSERKER` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
132. `ART-CLA-CLERIC` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
133. `ART-CLA-DRUID` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
134. `ART-CLA-PALADIN` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
135. `ART-CLA-PSION` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
136. `ART-CLA-RANGER` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
137. `ART-CLA-ROGUE` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
138. `ART-CLA-SORCERER` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
139. `ART-CLA-TRICKSTER` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
140. `ART-CLA-WIZARD` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
141. `ART-ANC-DEEP-ELF` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
142. `ART-ANC-DEMONBORN` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
143. `ART-ANC-DRAKEBLOOD` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
144. `ART-ANC-ELF` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
145. `ART-ANC-GNOME` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
146. `ART-ANC-GOBLIN` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
147. `ART-ANC-HALFLING` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
148. `ART-ANC-HUMAN` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
149. `ART-ANC-ORC` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
150. `ART-ANC-RATKIN` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
151. `ART-MON-AVATAR-OF-THE-OLD-GROWTH` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
152. `ART-MON-CAPTAIN-VEYR-OF-THE-FORSAKEN` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
153. `ART-MON-KHORRUN-THE-DRACOLICH` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
154. `ART-MON-MAELTHORN-THE-VERDANT` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
155. `ART-MON-SIRRACH-THE-BLACK` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
156. `ART-MON-THE-ANCIENT-VOID-DRAGON` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
157. `ART-MON-THE-ANTLERED-WARDEN-OF-THE-TITHE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
158. `ART-MON-THE-BROODMOTHER-PRIME` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
159. `ART-MON-THE-FROST-BAILIFF-MAGISTRATE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
160. `ART-MON-THE-HOLLOW-CROWN-OF-THE-ASHLANDS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
161. `ART-MON-THE-LAST-COLOSSUS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
162. `ART-MON-THE-SUN-CROWNED-PRINCE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
163. `ART-MON-THE-VOICE-BENEATH-THE-BELLS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
164. `ART-MON-VISATH-THE-WHITE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
165. `ART-MON-VOSSEGAR-OF-THE-FLOODED-CATHEDRAL` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
166. `ART-SCE-A-4-QUICKSTART-SCENARIO-THE-BROKEN-COURI` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
167. `ART-SCE-SCENARIO-1-HUNT-THE-WILD-BEAST` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
168. `ART-SCE-SCENARIO-1-PLUNDER-OF-THE-FROZEN-RUINS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
169. `ART-SCE-SCENARIO-1-THE-CRYSTAL-HARVEST` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
170. `ART-SCE-SCENARIO-1-THE-FALLEN-OBSERVATORY` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
171. `ART-SCE-SCENARIO-1-THE-OASIS-RAIDERS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
172. `ART-SCE-SCENARIO-1-THE-RELIQUARY-OF-EDRAVA-SALTT` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
173. `ART-SCE-SCENARIO-2-THE-ALCHEMIST-S-FROZEN-LABORA` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
174. `ART-SCE-SCENARIO-2-THE-CHASM-CROSSING` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
175. `ART-SCE-SCENARIO-2-THE-CINDER-LORD-S-LOST-BRAZIE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
176. `ART-SCE-SCENARIO-2-THE-GUARDIAN-S-TEST` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
177. `ART-SCE-SCENARIO-2-THE-LIZARDFOLK-S-STOLEN-OFFER` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
178. `ART-SCE-SCENARIO-2-THE-WHISPERING-GROVE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
179. `ART-SCE-SCENARIO-3-THE-BANDIT-S-TOLL` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
180. `ART-SCE-SCENARIO-3-THE-HAUNTED-MAUSOLEUM` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
181. `ART-SCE-SCENARIO-3-THE-MIRE-TITAN-S-FEN` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
182. `ART-SCE-SCENARIO-3-THE-QUAKE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
183. `ART-SCE-SCENARIO-3-THE-SHIFTING-SANDS-OF-TIME` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
184. `ART-SCE-SCENARIO-3-TOMB-OF-THE-SUNKEN-KINGS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
185. `ART-SCE-SCENARIO-4-THE-BLIGHTED-HEARTWOOD` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
186. `ART-SCE-SCENARIO-4-THE-CLOCKWORK-MENAGERIE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
187. `ART-SCE-SCENARIO-4-THE-SANDWYRM-S-LAIR` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
188. `ART-SCE-SCENARIO-4-THE-SEALED-ARCHIVE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
189. `ART-SCE-SCENARIO-4-THE-SPIDER-S-SILK-ROUTE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
190. `ART-SCE-SCENARIO-4-THE-UNDERMARCHES-OUTPOST-RAID` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
191. `ART-SCE-SCENARIO-5-SALTTIDE-S-RECKONING` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
192. `ART-SCE-SCENARIO-5-THE-AMBUSHED-EMISSARY` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
193. `ART-SCE-SCENARIO-5-THE-CURSED-COLOSSUS-OF-THE-WA` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
194. `ART-SCE-SCENARIO-5-THE-ICE-WYRM-S-HOARD` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
195. `ART-SCE-SCENARIO-5-THE-RELIQUARY-OF-BROKEN-SAINT` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
196. `ART-SCE-SCENARIO-5-THE-SHADOWED-UNDER-PASSAGE` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
197. `ART-SCE-SCENARIO-6-RITUAL-OF-THE-OLD-GROWTH` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
198. `ART-SCE-SCENARIO-6-THE-CINDER-LORD-S-OBSIDIAN-PR` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
199. `ART-SCE-SCENARIO-6-THE-ICEBOUND-COURT` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
200. `ART-SCE-SCENARIO-6-THE-IRON-VEIN-VAULT` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
201. `ART-SCE-SCENARIO-6-THE-RITUAL-OF-SHADOW-BINDING` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
202. `ART-SCE-SCENARIO-6-THE-SERPENT-S-SUNKEN-HOARD` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
203. `ART-WOR-1-2-THE-GRIM-WORLD` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
204. `ART-WOR-1-3-1-THE-FALL` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
205. `ART-WOR-1-3-2-THE-SIX-CLIMATES-OF-RUIN` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
206. `ART-WOR-1-3-3-THE-SIX-BASTIONS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
207. `ART-WOR-1-3-4-MAGIC-IN-THE-DYING-LANDS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
208. `ART-WOR-1-3-5-MONSTROUS-THREATS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
209. `ART-WOR-1-3-6-ADVENTURERS-AND-THE-ROAD` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
210. `ART-WOR-1-3-7-LEGENDS-AND-ECHOES` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
211. `ART-CAM-11-1-CAMPAIGN-OVERVIEW` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
212. `ART-CAM-THE-APOTHECARY` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
213. `ART-CAM-THE-ARCANUM` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
214. `ART-CAM-THE-ARMOURY` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
215. `ART-CAM-THE-BARRACKS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
216. `ART-CAM-THE-EXPEDITION-HALL` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
217. `ART-CAM-THE-OUTER-WALLS` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
218. `ART-CAM-THE-STRONGHOLD-CHAPEL` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
219. `ART-CAM-THE-UNDERCROFT` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
220. `ART-CAM-THE-VAULT` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
221. `ART-CAM-THE-WAR-ROOM` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
222. `ART-TRA-TIER-1-ARCANE-SPELLS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
223. `ART-TRA-TIER-1-DIVINE-PRAYERS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
224. `ART-TRA-TIER-1-DRUIDIC-RITUALS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
225. `ART-TRA-TIER-1-PSYCHIC-ABILITIES-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
226. `ART-TRA-TIER-1-SORCERIES-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
227. `ART-TRA-TIER-2-ARCANE-SPELLS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
228. `ART-TRA-TIER-2-DIVINE-PRAYERS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
229. `ART-TRA-TIER-2-DRUIDIC-RITUALS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
230. `ART-TRA-TIER-2-PSYCHIC-ABILITIES-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
231. `ART-TRA-TIER-2-SORCERIES-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
232. `ART-TRA-TIER-3-ARCANE-SPELLS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
233. `ART-TRA-TIER-3-DIVINE-PRAYERS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
234. `ART-TRA-TIER-3-DRUIDIC-RITUALS-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
235. `ART-TRA-TIER-3-PSYCHIC-ABILITIES-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
236. `ART-TRA-TIER-3-SORCERIES-D20` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
237. `ART-BAC-ALCHEMIST` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
238. `ART-BAC-APPRENTICE` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
239. `ART-BAC-ARTISAN` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
240. `ART-BAC-BELIEVER` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
241. `ART-BAC-COURIER` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
242. `ART-BAC-CULTIST` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
243. `ART-BAC-FARMER` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
244. `ART-BAC-HERMIT` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
245. `ART-BAC-MERCHANT` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
246. `ART-BAC-NOBLE` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
247. `ART-BAC-NOMAD` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
248. `ART-BAC-PAUPER` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
249. `ART-BAC-PERFORMER` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
250. `ART-BAC-SAILOR` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
251. `ART-BAC-SCHOLAR` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
252. `ART-BAC-SCOUT` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
253. `ART-BAC-SHEPHERD` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
254. `ART-BAC-SMUGGLER` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
255. `ART-BAC-SOLDIER` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
256. `ART-BAC-VAGABOND` (still, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
257. `ART-ITE-7-6-TREASURE-TABLES` (still, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
258. `ART-ITE-7-8-MELEE-WEAPONS` (still, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
259. `ART-CH01-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
260. `ART-CH02-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
261. `ART-CH03-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
262. `ART-CH04-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
263. `ART-CH05-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
264. `ART-CH06-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
265. `ART-CH07-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
266. `ART-CH08-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
267. `ART-CH09-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
268. `ART-CH10-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
269. `ART-CH11-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
270. `ART-COVER-002` (scene, 1536x1024, at most 5 attempts) - attach exactly: `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`

Image model: GPT Image 2.5 Sunburst if the image tool offers it (owner request), otherwise the default; record the
exact model name shown with `save --model`. Size: the listed size is the minimum and fixes the aspect, so request
the largest size the tool offers at that aspect. Art direction (owner, 2026-10-11): a notch more hand-drawn than the
first calibration, with confident hand-inked contours, economy of line, hatching only for form and shadow and open
white paper. No hyper-detail, stipple fields or noisy texture; the attached owner samples set the target.

For each item follow `production/art/skill/heraldry-classic-ink-art/SKILL.md` and `references/WORK_OPERATIONS_V6.md` exactly: `show ID`; the
verbatim prompt; only the listed references; save the native file as `/mnt/data/heraldry_work_scratch/<ID>_aN.png`; `check ID FILE`;
inspect the native image and print-size preview beside the references; `fidelity_gate.py create ... --out
/mnt/data/heraldry_work_scratch/<ID>.qa.json`; complete all ten criteria with real evidence; `save ID FILE --qa-file /mnt/data/heraldry_work_scratch/<ID>.qa.json
--must ... --avoid-clear`. Retries follow `references/REPAIR.md` within the attempt budget. Keep every native file
byte-identical.

## 4. Deliver a review ZIP and stop

```
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py sheet --refs --out /mnt/data/heraldry_work_scratch/sheet.jpg
python production/art/skill/heraldry-classic-ink-art/scripts/style_audit.py --repo . --limit 10 --out /mnt/data/heraldry_work_scratch/style.json
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py bundle --out /mnt/data/Heraldry_Work_Review_batch.zip --evidence /mnt/data/heraldry_work_scratch/sheet.jpg --evidence /mnt/data/heraldry_work_scratch/style.json --evidence /mnt/data/heraldry_work_scratch/smoke.json
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py status
```

`delivery_guard.py` does not apply here (it needs a Git checkout). The bundle carries the native images,
`receipts_append.jsonl`, every QA report, your evidence and a hash manifest. Give it to the owner as a
downloadable file and state plainly: nothing was pushed to GitHub; nothing is approved. Bundle at least every
10 saved images (the review bundle should stay under GitHub's 25 MB browser upload). Continue
until `status` says NOTHING LEFT (anchors phase: stop after the anchors). Claude Code reviews independently.
