# Heraldry ChatGPT Work input package: START HERE

Source: `xjordont/Heraldry` `main` commit `93d001f4270423dc861ebcd93b3e775501cda847`. Queue phase `anchors`, 5 items.
This package replaces the authenticated Git checkout for **inputs only**. It holds the exact queue, prompts,
references (real image bytes), the complete v6 skill, receipts and selection state, with SHA-256 for every file
in `WORK_PACKAGE.json`. It cannot push anything to GitHub, and it approves nothing.

## 1. Unpack and verify (no Git, no credentials)

Unzip into the new empty folder `/mnt/data/heraldry_work` (any empty folder works; these paths assume this one) and
run every command from inside it. Do not run `git init`, `git clone` or `git pull` here. The helper keeps attempt
counts, print-size previews and QA copies in the sibling folder `/mnt/data/heraldry_work_scratch`; put your own scratch files
(native images, QA JSON, smoke record) there too, never inside the package folder.

```
cd /mnt/data/heraldry_work
python production/art/skill/heraldry-classic-ink-art/scripts/work_preflight.py --repo . --offline-package --require-installed
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py doctor
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py status
```

Expected: `status` READY, `source.kind` offline_package, `delivery` bundle, `remote_access` NOT_ATTEMPTED,
`image_and_reference_tool` UNVERIFIED. Any BLOCKED result: stop and report it word for word. Never edit a
packaged file; the preflight rejects any change (receipts may only grow).

## 2. Smoke test inside Work (required; no script can do it)

Confirm that the image tool accepts every reference of an item as an attached image and that the generated
native file is on disk where Python can read it. Only if all three are true, write `/mnt/data/heraldry_work_scratch/smoke.json`:
`{"image_generated": true, "all_queue_references_attached": true, "native_file_accessible": true, "note": "..."}`
and rerun the preflight with `--smoke-file /mnt/data/heraldry_work_scratch/smoke.json`. If the tool cannot take every listed
reference, STOP and report a capability blocker. Never generate without them.

## 3. Generate the five calibration anchors only

1. `ART-CLI-THE-GREENMARK` (scene, 1536x1024, at most 3 attempts) - attach exactly: `assets/art/incoming/ART-BAS-GREYTHORN.jpg`, `assets/art/style/STYLE-REF-01-scene-hatching.jpg`, `assets/art/style/STYLE-REF-02-panorama-line.jpg`
2. `ART-MON-GIANT-TARANTULA` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
3. `ART-MON-UNDEAD-CHAMPION` (creature, 1024x1024, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
4. `ART-CLA-FIGHTER` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`
5. `ART-ANC-DWARF` (person, 1024x1536, at most 3 attempts) - attach exactly: `assets/art/style/STYLE-REF-03-figure-spotblack.jpg`

For each item follow `production/art/skill/heraldry-classic-ink-art/SKILL.md` and `references/WORK_OPERATIONS_V6.md` exactly: `show ID`; the
verbatim prompt; only the listed references; save the native file as `/mnt/data/heraldry_work_scratch/<ID>_aN.png`; `check ID FILE`;
inspect the native image and print-size preview beside the references; `fidelity_gate.py create ... --out
/mnt/data/heraldry_work_scratch/<ID>.qa.json`; complete all ten criteria with real evidence; `save ID FILE --qa-file /mnt/data/heraldry_work_scratch/<ID>.qa.json
--must ... --avoid-clear`. Retries follow `references/REPAIR.md` within the attempt budget. Keep every native file
byte-identical.

## 4. Deliver a review ZIP and stop

```
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py sheet --refs --out /mnt/data/heraldry_work_scratch/anchors_sheet.jpg
python production/art/skill/heraldry-classic-ink-art/scripts/style_audit.py --repo . --limit 10 --out /mnt/data/heraldry_work_scratch/anchors_style.json
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py bundle --out /mnt/data/Heraldry_Work_Review_anchors.zip --evidence /mnt/data/heraldry_work_scratch/anchors_sheet.jpg --evidence /mnt/data/heraldry_work_scratch/anchors_style.json --evidence /mnt/data/heraldry_work_scratch/smoke.json
python production/art/skill/heraldry-classic-ink-art/scripts/heraldry_art.py status
```

`delivery_guard.py` does not apply here (it needs a Git checkout). The bundle carries the native images,
`receipts_append.jsonl`, every QA report, your evidence and a hash manifest. Give it to the owner as a
downloadable file and state plainly: nothing was pushed to GitHub; nothing is approved. Then STOP. Claude Code
reviews the anchors independently and publishes the next queue and package.
